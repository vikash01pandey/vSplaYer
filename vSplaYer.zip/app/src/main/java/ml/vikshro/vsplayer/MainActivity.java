package ml.vikshro.vsplayer;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.SeekBar;
import android.media.MediaPlayer;
import java.util.Timer;
import java.util.TimerTask;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;
import android.view.View;
import java.text.DecimalFormat;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double n = 0;
	private double r = 0;
	private double songpos = 0;
	private String currentfile = "";
	private String songmin = "";
	private String sonsec = "";
	private String folder = "";
	private String folderName = "";
	
	private ArrayList<HashMap<String, Object>> allmusic = new ArrayList<>();
	private ArrayList<String> fileList = new ArrayList<>();
	private ArrayList<String> folderList = new ArrayList<>();
	
	private LinearLayout head;
	private LinearLayout body;
	private LinearLayout progress;
	private LinearLayout linear1;
	private LinearLayout reading;
	private ImageView logo;
	private TextView title;
	private ImageView imageview1;
	private TextView abt;
	private ListView l1;
	private ImageView previous;
	private ImageView pp;
	private ImageView stop;
	private ImageView next;
	private SeekBar s1;
	private TextView str;
	private TextView mnam;
	private TextView stp;
	
	private MediaPlayer mp;
	private TimerTask timer;
	private SharedPreferences sp;
	private Intent splash = new Intent();
	private AlertDialog.Builder about;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		head = (LinearLayout) findViewById(R.id.head);
		body = (LinearLayout) findViewById(R.id.body);
		progress = (LinearLayout) findViewById(R.id.progress);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		reading = (LinearLayout) findViewById(R.id.reading);
		logo = (ImageView) findViewById(R.id.logo);
		title = (TextView) findViewById(R.id.title);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		abt = (TextView) findViewById(R.id.abt);
		l1 = (ListView) findViewById(R.id.l1);
		previous = (ImageView) findViewById(R.id.previous);
		pp = (ImageView) findViewById(R.id.pp);
		stop = (ImageView) findViewById(R.id.stop);
		next = (ImageView) findViewById(R.id.next);
		s1 = (SeekBar) findViewById(R.id.s1);
		str = (TextView) findViewById(R.id.str);
		mnam = (TextView) findViewById(R.id.mnam);
		stp = (TextView) findViewById(R.id.stp);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		about = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				(new GetSongsTask()).execute();
				l1.setAdapter(new L1Adapter(allmusic));
				((BaseAdapter)l1.getAdapter()).notifyDataSetChanged();
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(allmusic.size())).concat(" songs added"));
			}
		});
		
		abt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				about.setTitle("About: vSplaYer");
				about.setMessage("Vik Software Handling and Research Organization develop this Application for android.It is basic version of android and this application is going to our research and Premodified this for multiple purpose.\n\nvisit : http://vikshro.ml\n\nLike On \nhttp://facebook.com/vikshro\nhttp://instagram.com/vikshro\n\nAbout Application:\nVersion :1.0\nLaunched : not declared\nOwner: VIKSHRO\n\n© Copyright VIKSHRO");
				about.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), "Kindly Visit Our Official Site for more information.");
					}
				});
				about.create().show();
			}
		});
		
		l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (songpos == -1) {
					_mpcreate(_position);
					_mpstart();
				}
				else {
					if (songpos == _position) {
						if (mp.isPlaying()) {
							_mppause();
						}
						else {
							_mpstart();
						}
					}
					else {
						if (mp.isPlaying()) {
							_mppause();
						}
						_mpcreate(_position);
						_mpstart();
					}
				}
			}
		});
		
		l1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		previous.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_previous1();
			}
		});
		
		pp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (((songpos - 1) < -1) || ((allmusic.size() - 1) < songpos)) {
					songpos = 0;
					_mpcreate(songpos);
				}
				else {
					
				}
				if (mp.isPlaying()) {
					_mppause();
				}
				else {
					_mpstart();
				}
			}
		});
		
		stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (songpos == -1) {
					
				}
				else {
					if (mp.isPlaying()) {
						_mppause();
						s1.setProgress((int)0);
						mp.seekTo((int)(0));
					}
				}
			}
		});
		
		next.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_next1();
			}
		});
		
		s1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				if (!(songpos == -1)) {
					mp.seekTo((int)(s1.getProgress()));
				}
			}
		});
		
		stp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				(new GetSongsTask()).execute();
			}
		});
	}
	private void initializeLogic() {
		_splashsc();
		songpos = -1;
		if (sp.getString("allsongs", "").equals("")) {
			(new GetSongsTask()).execute();
		}
		else {
			allmusic = new Gson().fromJson(sp.getString("allsongs", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			l1.setAdapter(new L1Adapter(allmusic));
			((BaseAdapter)l1.getAdapter()).notifyDataSetChanged();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _mpcreate (final double _pos) {
		currentfile = allmusic.get((int)_pos).get("song").toString();
		mnam.setText(Uri.parse(currentfile).getLastPathSegment());
		pp.setEnabled(true);
		stop.setEnabled(true);
		songpos = _pos;
		mp = MediaPlayer.create(getApplicationContext(), Uri.fromFile(new java.io.File(currentfile)));
		mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
			
			public void onCompletion(MediaPlayer mp){
				mp.reset();
				mp.release();
				if ((songpos + 1) == allmusic.size()) {
					songpos = 0;
				}
				else {
					if ((songpos - 1) == -1) {
						songpos = allmusic.size() - 1;
					}
					else {
						songpos = songpos + 1;
					}
				}
				if (songpos < allmusic.size()) {
					_mpcreate(songpos);
					_mpstart();
				}
			}
		});
		s1.setMax((int)mp.getDuration());
		songmin = new DecimalFormat("00").format((mp.getDuration() / 1000) / 60);
		sonsec = new DecimalFormat("00").format((mp.getDuration() / 1000) % 60);
		stp.setText(songmin.concat(":".concat(sonsec)));
	}
	
	
	private void _mpstart () {
		mp.start();
		pp.setImageResource(R.drawable.paus);
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						s1.setProgress((int)mp.getCurrentPosition());
						str.setText(new DecimalFormat("00").format((mp.getCurrentPosition() / 1000) / 60).concat(":".concat(new DecimalFormat("00").format((mp.getCurrentPosition() / 1000) % 60))));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(400), (int)(400));
	}
	
	
	private void _mppause () {
		mp.pause();
		timer.cancel();
		pp.setImageResource(R.drawable.play);
	}
	
	
	private void _splashsc () {
		splash.setClass(getApplicationContext(), SplashActivity.class);
		startActivity(splash);
	}
	
	
	private void _previous1 () {
		if (mp.isPlaying()) {
			mp.pause();
		}
		mp.reset();
		mp.release();
		if ((songpos - 1) == -1) {
			songpos = allmusic.size() - 1;
			_mpcreate(songpos);
			_mpstart();
		}
		else {
			_mpcreate(songpos - 1);
			_mpstart();
		}
	}
	
	
	private void _next1 () {
		if (mp.isPlaying()) {
			mp.pause();
		}
		mp.reset();
		mp.release();
		if ((songpos + 1) == allmusic.size()) {
			songpos = 0;
			_mpcreate(songpos);
			_mpstart();
		}
		else {
			_mpcreate(songpos + 1);
			_mpstart();
		}
	}
	
	
	private void _getFileList (final String _filePath) {
		FileUtil.listDir(_filePath, fileList);
		n = 0;
		for(int _repeat118 = 0; _repeat118 < (int)(fileList.size()); _repeat118++) {
			if (FileUtil.isFile(fileList.get((int)(n)))) {
				if (fileList.get((int)(n)).endsWith(".mp3")) {
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put("song", fileList.get((int)(n)));
						allmusic.add(_item);
					}
					
				}
			}
			else {
				if (FileUtil.isDirectory(fileList.get((int)(n)))) {
					folderList.add(fileList.get((int)(n)));
				}
			}
			n++;
		}
		_searchFolders();
	}
	
	
	private void _searchFolders () {
		r++;
		if (r < (folderList.size() + 1)) {
			folder = folderList.get((int)(r - 1));
			folderName = Uri.parse(folder.substring((int)(0), (int)(folder.length() - 1))).getLastPathSegment();
			if (folderName.toLowerCase().startsWith("sys")) {
				_searchFolders();
			}
			else {
				if (folderName.startsWith(".")) {
					_searchFolders();
				}
				else {
					_getFileList(folderList.get((int)(r - 1)));
				}
			}
		}
	}
	
	
	private void _extra () {
	}
	
	private class GetSongsTask extends AsyncTask<Void, Void, Void> {
		
		@Override
		protected void onPreExecute() {
		}
		
		@Override
		protected Void doInBackground(Void... path) {
			r = 0;
			allmusic.clear();
			folderList.clear();
			_getFileList(FileUtil.getExternalStorageDir());
			sp.edit().putString("allsongs", new Gson().toJson(allmusic)).commit();
			return null;
		}
		
		 @Override
		protected void onProgressUpdate(Void... values) {
		}
		
		@Override
		protected void onPostExecute(Void param){
			l1.setAdapter(new L1Adapter(allmusic));
			SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(allmusic.size())).concat(" songs added"));
			
		}
	}
	
	
	public class L1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public L1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.music, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView t1 = (TextView) _v.findViewById(R.id.t1);
			
			t1.setText(Uri.parse(allmusic.get((int)_position).get("song").toString()).getLastPathSegment());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
